# Sara Industries — GST Invoice App (Flutter)

Includes:
- Invoice with GST 18% (CGST 9% + SGST 9%), HSN 373527
- PDF share
- Orders timeline, Stock inward, Materials (unit cost), Accounts
- Login: admin / 1234

## Build locally
flutter pub get
flutter build apk --release
# APK at build/app/outputs/flutter-apk/app-release.apk

## Build via GitHub Actions
- Push this project → Actions → workflow runs → download `app-release.apk` from Artifacts.
- Workflow auto-creates **android/** and **ios/** if missing (no setup errors).

## Build via Codemagic
- Upload this ZIP → start Android workflow → download APK artifact.
- Config auto-creates **android/** and **ios/** on the server, preventing missing-folder errors.
